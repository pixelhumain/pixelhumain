Portfilter
===========

Very Lightweight Portfolio Filter for Bootstrap


Usage
-----

	For handlers
		<tag data-toggle="portfilter" data-target="targetname">...
	For items
		<tag data-tag="targetname">...
About
-----
http://geedmo.com

